# Ansible Collection - my_own_namespace.yandex_cloud_elk
=========

Коллекция Ansible, содержащая собственный модуль для создания текстовых файлов на удалённом хосте.


Moduls
----------------

my_own_module

Создаёт текстовый файл по указанному пути с заданным содержимым.

License
-------

MTI

Author Information
------------------

Ruslan Fedyunin.
