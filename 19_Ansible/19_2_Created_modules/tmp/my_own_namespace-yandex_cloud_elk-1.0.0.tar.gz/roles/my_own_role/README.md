my_own_role
=========

Роль, использующая модуль my_own_module.

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

- hosts: localhost
  roles:
    - my_own_namespace.yandex_cloud_elk.my_own_role

License
-------

MTI

Author Information
------------------

Ruslan Fedyunin.
