#!/usr/bin/python

# Copyright: (c) 2024, Fedjunin Ruslan <rfedyunin@example.org>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

DOCUMENTATION = r'''
---
module: my_own_module

short_description: This is my own module for creating text files

version_added: "1.0.0"

description:
    - This module creates a text file on the remote host.
    - The file path is defined by the C(path) parameter.
    - The file content is defined by the C(content) parameter.

options:
    path:
        description: Path to the file to create.
        required: true
        type: str
    content:
        description: Content to write to the file.
        required: true
        type: str

author:
    - Fedjunin Ruslan (@rfedyunin)
'''

EXAMPLES = r'''
# Create a file with content
- name: Create a text file
  my_own_namespace.yandex_cloud_elk.my_own_module:
    path: /tmp/test.txt
    content: "Hello, world!"

# Create another file
- name: Create another file
  my_own_namespace.yandex_cloud_elk.my_own_module:
    path: /tmp/hello.txt
    content: "Hello from Ansible module!"
'''

RETURN = r'''
# These are examples of possible return values, and in general should use other names for return values.
message:
    description: The output message that the module generates.
    type: str
    returned: always
    sample: 'File created successfully'
'''

import os
from ansible.module_utils.basic import AnsibleModule


def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = dict(
        path=dict(type='str', required=True),
        content=dict(type='str', required=True)
    )

    # seed the result dict in the object
    result = dict(
        changed=False,
        message=''
    )

    # the AnsibleModule object will be our abstraction working with Ansible
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    # if the user is working with this module in only check mode we do not
    # want to make any changes to the environment, just return the current
    # state with no modifications
    if module.check_mode:
        module.exit_json(**result)

    # get parameters
    path = module.params['path']
    content = module.params['content']

    # check if file exists and has the same content
    file_exists = os.path.exists(path)
    if file_exists:
        with open(path, 'r') as f:
            existing_content = f.read()
        if existing_content == content:
            result['message'] = 'File already exists with the same content'
            module.exit_json(**result)

    # create or update the file
    try:
        with open(path, 'w') as f:
            f.write(content)
        result['changed'] = True
        result['message'] = 'File created/updated successfully'
    except Exception as e:
        module.fail_json(msg=f'Failed to create file: {str(e)}', **result)

    # in the event of a successful module execution, you will want to
    # simple AnsibleModule.exit_json(), passing the key/value results
    module.exit_json(**result)


def main():
    run_module()


if __name__ == '__main__':
    main()
